<?php
if (file_exists($_SERVER['DOCUMENT_ROOT']."/framanav/nav.inc.html") ) {
 include_once($_SERVER['DOCUMENT_ROOT']."/framanav/nav.inc.html");
}
?>