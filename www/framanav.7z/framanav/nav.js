/* nav.js par pyg@framasoft.net pour Framasoft
Contient les divers appels aux scripts n�c�ssaires pour la Framanav */

$(document).ready(function(){
	
	// on  fait bliker le logo "faire un don" en bas � droite
	p_donationsTimer(false); 
	
	//on recup�re le nom de domaine actuel
	var navdomain=document.domain;
	navdomain = navdomain.replace(/^(www|test)\./i, "");
	navdomain = navdomain.replace(/\.(com|net|org)$/i, "");
	$('#framalinks li[rel='+navdomain+']').addClass('nav-active'); // on active la couleur sp�cifique pour le domaine
	
	// on change la couleur du textarea
	$("#head-search input.textarea").focus(function () {
         $(this).css('background-color','#fff');
    });
	$("#head-search input.textarea").blur(function () {
         $(this).css('background-color','#F3F3F3');
    });

	// r�cup�ration du flux RSS et affichage dans #fluxRSS
	$('#fluxRSS').rssfeed('http://framapack.org/~framaflux/framanav_rss.php', {
			limit: 10,
			header: false,
			titletag: 'div',
			date: false,
			content: false,
			snippet: false,
			showerror: true,
			zcss: 'rssFeed',
			truncateTitle: 65,
			truncateContent: 300,
			errormsg: ''}).ajaxStop(function() {
		$('#fluxRSS div.rssBody').vTicker({ showItems: 1});
	});

        // bouton pour stoper le d�filement du flux RSS
        $('#rss_pause_link').click (function () {$('#fluxRSS div.rssBody').toggle ('slow');});


// ---------------- d�but des Tooltips ------------------------------------------------------------------------------------------------
	// style par defaut des tooltips
	$.fn.qtip.styles.navStyle = { // Last part is the name of the style
      width: {
        min: 0,
        max: 350
      },
      padding: 5,
      background: '#3F6D90',
      color: '#FFFFFF',
      fontSize: 12,
      textAlign: 'center',
      border: {
        width: 4,
        color: '#599CBF'
      },
      tip: 'topLeft'
 	}	
	
	$('#framalinks li.ltip a, #donation').click(function() {
	  attr = $(this).attr("rel");
	  if (typeof(_gaq) != 'undefined') _gaq.push(['_trackEvent', 'Framanav', 'Click', attr]);
	});
	
	
  $('#framalinks li.rtip a[href][title]').qtip({
    content: {
      text: false
    },
    style: 'navStyle', 
	  hide: {
		fixed: true
	 },
	show: { solo: true, delay: 0 },
    position: {
      corner: {
        target: 'bottomMiddle',
        tooltip: 'topLeft'
      },
	  adjust: { x: 20 }
    }
  });
 
  $('#framalinks li.ltip a[href][title]').qtip({
    content: {
      text: false
    },
    style: {
      width: {
        min: 0,
        max: 350
      },
      padding: 5,
      background: '#3F6D90',
      color: '#FFFFFF',
      fontSize: 12,
      textAlign: 'center',
      border: {
        width: 4,
        color: '#599CBF'
      },
      tip: 'topRight'
	  },
	hide: {
		fixed: true
	},
	show: { solo: true, delay: 0 },
    position: {
      corner: {
        target: 'LeftBottom',
        tooltip: 'rightTop'
      }
    }
  });


	$('a[rel="informations"]').qtip(
   {
      content: {
         title: {
            text: 'Informations',
            button: 'Fermer'
         },
         text: '<iframe src="http://nav.framasoft.org/framanav/framareseau/" width="710" height="380" frameBorder="no" SCROLLING=NO></iframe>'
      },
      position: {
         target: $(window), // $(document) posait probleme...
         corner: 'center'
      },
      show: {
         when: 'click',
         solo: true, 
		 delay: 0
      },
      hide: false,
      style: {
         width: { max: 710 },
         padding: '0px',
	      border: {
	        width: 4,
	        color: '#599CBF'
	      },
         name: 'light'
      },
      api: {
         beforeShow: function()
         {
            $('#qtip-blanket').fadeIn(this.options.show.effect.length);
         },
         beforeHide: function()
         {
            $('#qtip-blanket').fadeOut(this.options.hide.effect.length);
         }
      }
   });

  $('a[rel="OpenID"]').qtip(
   {
      content: {
        title: { text: 'Identification', button: 'Fermer'},
		url: '/framanav/openid/openid.php'
      },
      position: {target: $(window), corner: 'center'}, show: { when: 'click',solo: true, delay: 0}, hide: false,
      style: {width: 350,padding: '4px',border: {width: 4, color: '#599CBF'},name: 'light'},
      api: {
         beforeShow: function() { $('#qtip-blanket').fadeIn(this.options.show.effect.length); }, beforeHide: function() { $('#qtip-blanket').fadeOut(this.options.hide.effect.length); }
      }
   });
   
  $('a[rel="Donner"]').qtip(
   {
      content: {
         title: {text: 'Donner � Framasoft', button: 'Fermer'},
			text: 'Avec un exemple de <b>boite de dialogue</b> ! <br /><br />' +
               'comme on peut y mettre un peu ce qu\'on veut (textes, images, url locale, etc),' +
               '�a peut s\'av�rer tr�s pratique pour afficher des infos sans surcharger la page' +
			   '<br/><a href="http://fr.wikipedia.org/wiki/Framasoft" title="Suivez-nous sur identi.ca ou twitter"><img src="/framanav/img/twitter.png" /></a>'
      },
      position: {target: $(window), corner: 'center'}, show: { when: 'click',solo: true, delay: 0}, hide: false,
      style: {width: { max: 350 },padding: '14px',border: {width: 4, color: '#599CBF'},name: 'light'},
      api: {
         beforeShow: function() { $('#qtip-blanket').fadeIn(this.options.show.effect.length); }, beforeHide: function() { $('#qtip-blanket').fadeOut(this.options.hide.effect.length); }
      }
   });
  
  $('a[rel="microblog"]').qtip(
   {
      content: {
         title: { text: 'Derni&egrave;res nouvelles', button: 'Fermer'},
			text: '<iframe src="http://nav.framasoft.org//framanav/microblog/index.html?1" width="'+ ($(document).width()-200) +'" height="380" frameBorder="no"></iframe>' 
      },
      position: {target: $(window), corner: 'center'}, show: { when: 'click',solo: true, delay: 0}, hide: false,
      style: {width: { max: ($(document).width()-100) }, padding: '0px', border: {width: 4, color: '#599CBF'},name: 'light'},
      api: {
         beforeShow: function() { $('#qtip-blanket').fadeIn(this.options.show.effect.length); }, beforeHide: function() { $('#qtip-blanket').fadeOut(this.options.hide.effect.length); }
      }
   });

  $('a[rel="rss"]').qtip(
   {
      content: {
         title: { text: 'Flux RSS', button: 'Fermer'},
		 text: '<div id="fullFeed" style="height:250px; overflow-y:auto;">flux</div>' +
			   '<br/><div class="rssFollow"><a href="http://framapack.org/~framaflux/rss.php" title="Tous les flux du r�seau Framasoft">Tous nos flux RSS</a></div>'
      },
      position: {target: $(window), corner: 'center'}, show: { when: 'click',solo: true}, hide: false,
      style: {width: 550, padding: '0px','background-color':'#ccc',border: {width: 4, color: '#599CBF'}},
      api: {
        beforeShow: function() { 
			$('#qtip-blanket').fadeIn(this.options.show.effect.length); 
			$('#fullFeed').rssfeed('http://framapack.org/~framaflux/rss.php', {
				limit: 50,
				header: false,
				titletag: 'div',
				date: false,
				content: false,
				snippet: false,
				showerror: true,
				truncateContent: 500,
				zcss: 'rssFullFeed',
				addDomain: true,
				errormsg: ''});
			},
			beforeHide: function() { $('#qtip-blanket').fadeOut(this.options.hide.effect.length); }
      }
   });  
 

  $('a[rel="Recherche"]').qtip({
    content: {
			text: '<p>Rechercher sur Framasoft</p><form id="navhead-search" action="http://www.google.com/cse">'+
			        '<input type="hidden" value="partner-pub-1632705613293821:8318046087" name="cx"/>'+
			        '<input type="hidden" name="ie" value="UTF-8" />'+
			        '<input type="text" size="25" name="q" value="" class="textarea"/>'+
			        '<input type="submit" value="Go" name="sa" class="button"/>'+
			      '</form>'
    },
    style: {
      width: {
        min: 280,
        max: 450
      },
      padding: 5,
      background: '#3F6D90',
      color: '#FFFFFF',
      //fontSize: 12,
      textAlign: 'center',
      border: {
        width: 4,
        color: '#599CBF'
      },
      tip: 'topRight'
    }, 
	  hide: {
		fixed: true,
		delay: 1500,
		effect: { type: 'fade', length: 200 }
	 },
	show: { delay: 0, effect: { type: 'slide', length: 500 }, solo: true },
    position: {
      corner: {
        target: 'bottomMiddle',
        tooltip: 'topRight'
      }
    }
  });

   $('a[rel="newsletter"]').qtip({
    content: {
			text: '<p>Lettre d\'information Framasoft</p>'+
				  '<form method=post name="subscribeform" action="http://asso.framasoft.org/php_list/lists/?p=subscribe&id=2">'+
					'<input type="text" name="email" value="votre email" size="40" onclick="if (this.value==\'votre email\') this.value=\'\';"> '+
					'<input type=submit name="subscribe" value="Go" onClick="return p_isValidEmail(document.subscribeform.email.value)" class="button" >'+
					'<input type=hidden name="htmlemail" value="0"> '+
					'<input type="hidden" name="list[5]" value="signup">'+
					'<input type="hidden" name="listname[5]" value="Newsletter"/>' +
					'<div style="display:none"><input type="text" name="VerificationCodeX" value="" size="20"></div>'+
					
			      '</form>'+
			      '<small>Abonnez-vous et recevez r&eacute;guli&egrave;rement <br/>les informations du r&eacute;seau Framasoft. '+
				  '<a href="http://soutenir.framasoft.org/newsletter" style="color:#DDD">Plus d\'infos</a></small>'
    },
    style: {
      width: {
        min: 280,
        max: 450
      },
      padding: 5,
      background: '#3F6D90',
      color: '#FFFFFF',
      //fontSize: 12,
      textAlign: 'center',
      border: {
        width: 4,
        color: '#599CBF'
      },
      tip: 'topRight'
    }, 
	  hide: {
		fixed: true,
		delay: 1500,
		effect: { type: 'fade', length: 200 }
	 },
	show: { delay: 0, effect: { type: 'slide', length: 500 }, solo: true },
    position: {
      corner: {
        target: 'bottomMiddle',
        tooltip: 'topRight'
      }
    }
  }); 
  
  
// Fenetre modale pour les tooltips en popup
   $('<div id="qtip-blanket">')
      .css({
         position: 'absolute',
         top: $(document).scrollTop(),
         left: 0,
         height: $(document).height(),
         width: '100%', 

         opacity: 0.7,
         backgroundColor: 'black',
         zIndex: 5000
      })
      .appendTo(document.body)
      .hide();
// ---------------- Fin des Tooltips ------------------------------------------------------------------------------------------------


  $('#framanav ul#framalinks li.others ul').hide(); // on cache le sous-menu
  $('.others').hover( //on affiche le sous-menu
    function(){
      $('#framanav ul#framalinks li.others ul').show();
    },
    function(){
      $('#framanav ul#framalinks li.others ul').hide();
    }
  )
  
  // on masque les �l�ments "dons", et "recherche" si la r�solution est trop faible
  p_adaptNavWidth(0); // au chargement
  $(window).resize(	function () {
		p_adaptNavWidth(1000) // au redimensionnement
	}
  )
 }); 

/**
 * Plugin: jquery.zRSSFeed
 * 
 * Version: 1.0.1
 * (c) Copyright 2010, Zazar Ltd
 * 
 * Description: jQuery plugin for display of RSS feeds via Google Feed API
 *              (Based on original plugin jGFeed by jQuery HowTo)
 * 
 * History:
 * 1.0.1 - Corrected issue with multiple instances
 *
 **/

(function($){

	var current = null; 
	
	$.fn.rssfeed = function(url, options) {	
	
		// Set pluign defaults
		var defaults = {
			limit: 10,
			header: true,
			titletag: 'h4',
			date: true,
			content: true,
			snippet: true,
			showerror: true,
			errormsg: '',
			zcss: 'rssFeed', // ajout� par pyg
			truncateTitle: 650,
			truncateContent: 3000,
			addDomain: false,
			key: null
		};  
		var options = $.extend(defaults, options); 
		
		// Functions
		return this.each(function(i, e) {
			var $e = $(e);
			
			// Add feed class to user div
			if (!$e.hasClass(options.zcss)) $e.addClass(options.zcss); // modifi� par pyg
			
			// Check for valid url
			if(url == null) return false;

			// Create Google Feed API address
			var api = "http://ajax.googleapis.com/ajax/services/feed/load?v=1.0&callback=?&q=" + url;
			if (options.limit != null) api += "&num=" + options.limit;
			if (options.key != null) api += "&key=" + options.key;

			// Send request
			$.getJSON(api, function(data){
				
				// Check for error
				if (data.responseStatus == 200) {
	
					// Process the feeds
					_callback(e, data.responseData.feed, options);
				} else {

					// Handle error if required
					if (options.showerror)
						if (options.errormsg != '') {
							var msg = options.errormsg;
						} else {
							var msg = data.responseDetails;
						};
						$(e).html('<div class="rssError"><p>'+ msg +'</p></div>');
				};
			});				
		});
	};
	
	// Callback function to create HTML result
	var _callback = function(e, feeds, options) {
		if (!feeds) {
			return false;
		}
		var html = '';	
		var row = 'odd';	
		
		// Add header if required
		if (options.header)
			html +=	'<div class="rssHeader">' +
				'<a href="'+feeds.link+'" title="'+ feeds.description +'">'+ feeds.title +'</a>' +
				'</div>';
			
		// Add body
		html += '<div class="rssBody">' +
			'<ul>';
		
		// Add feeds
		for (var i=0; i<feeds.entries.length; i++) {
			
			// Get individual feed
			var entry = feeds.entries[i];
			
			// Format published date
			var entryDate = new Date(entry.publishedDate);
			var pubDate = entryDate.toLocaleDateString() + ' ' + entryDate.toLocaleTimeString();
			
			// Add feed row
			var summary = "";
			if (rssTruncate(entry.content) != "") { summary = '<span class="summary">'+ rssTruncate(entry.content, options.truncateContent) +'</span>'; }
			
			var transformContent = "";
			transformContent += options.addDomain ? p_GetFeedDomain(entry.link) : "";
			transformContent += rssTruncate(entry.title, options.truncateTitle );
			transformContent += summary;
			
			html += '<li class="rssRow '+row+'">'
			
			html += '<a href="'+ entry.link +'" class="tip" target="_blank">'+ transformContent +'</a>' //modifi� par pyg
			if (options.date) html += '<div>'+ pubDate +'</div>'
			if (options.content) {
			
				// Use feed snippet if available and optioned
				if (options.snippet && entry.contentSnippet != '') {
					var content = entry.contentSnippet;
				} else {
					var content = entry.content;
				}
				
				html += '<p>'+ content +'</p>'
			}
			
			html += '</li>';
			
			// Alternate row classes
			if (row == 'odd') {
				row = 'even';
			} else {
				row = 'odd';
			}			
		}
		
		html += '</ul>' +
			'</div>'
		
		$(e).html(html);
	};
})(jQuery);
 

/*
* Tadas Juozapaitis ( kasp3rito@gmail.com )
*/
(function($){
$.fn.vTicker = function(options) {
	var defaults = {
		speed: 700,
		pause: 4000,
		showItems: 1,
		animation: '',
		height: 1,
		mousePause: true,
		isPaused: false
	};

	var options = $.extend(defaults, options);

	moveUp = function(obj2, height){
		if(options.isPaused)
			return;
		
		var obj = obj2.children('ul');
		
    	first = obj.children('li:first').clone(true);
		
    	obj.animate({top: '-=' + height + 'px'}, options.speed, function() {
        	$(this).children('li:first').remove();
        	$(this).css('top', '0px');
        });
		
		if(options.animation == 'fade')
		{
			obj.children('li:first').fadeOut(options.speed);
			obj.children('li:last').hide().fadeIn(options.speed);
		}

    	first.appendTo(obj);
	};
	
	return this.each(function() {
		var obj = $(this);
		var maxHeight = 0;

		obj.css({overflow: 'hidden', position: 'relative'})
			.children('ul').css({position: 'relative', margin: 0, padding: 0}) //modifi� par pyg pour IE (avant : position: 'absolute')
			.children('li').css({margin: 0, padding: 0});

		obj.children('ul').children('li').each(function(){
			if($(this).height() > maxHeight)
			{
				maxHeight = $(this).height();
			}
		});

		obj.children('ul').children('li').each(function(){
			$(this).height(maxHeight);
		});

		obj.height(maxHeight * options.showItems);
		
    	var interval = setInterval(function(){ moveUp(obj, maxHeight); }, options.pause);
		
		if(options.mousePause)
		{
			obj.bind("mouseenter",function(){
				options.isPaused = true;
			}).bind("mouseleave",function(){
				options.isPaused = false;
			});
		}
	});
};
})(jQuery);

 /* fonctions perso */
 
 var truncate = function (str, limit) {
	var bits, i;

	bits = str.split('');
	if (bits.length > limit) {
		for (i = bits.length - 1; i > -1; --i) {
			if (i > limit) {
				bits.length = i;
			}
			else if (' ' === bits[i]) {
				bits.length = i;
				break;
			}
		}
		bits.push('...');
	}
	return bits.join('');
};
 
 function rssTruncate(data, length) { 
 data = data.replace(/<\/?[^>]+>/gi, ''); 
 data = truncate(data, length);
 return jQuery.trim(data);
 
 };
 
 
function p_maxHeight() {
	if ($(window).height()<600) return 600
	return $(window).height();
}

function navreadCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function p_adaptNavWidth(length) {
		
		if ($(window).width() < 1200) $('#framanav #fluxRSS').fadeOut(length);
		if ($(window).width() > 1200) $('#framanav #fluxRSS').fadeIn(length);
                if ($(window).width() < 1200) $('#rss_pause_link').parent().fadeOut(length);
                if ($(window).width() > 1200) $('#rss_pause_link').parent().fadeIn(length);
		if ($(window).width() < 850) $('#framanav .dons').fadeOut(length);
		if ($(window).width() > 850) $('#framanav .dons').fadeIn(length);
		if ($(window).width() <= 1400) $('#framanav #head-search').fadeOut(length);
		if ($(window).width() > 1400) $('#framanav #head-search').fadeIn(length);
		if ($(window).width() < 1400) $('#framanav .recherche').fadeIn(length);
		if ($(window).width() >= 1400) $('#framanav .recherche').fadeOut(length);
		if ($(window).width() < 1400) $('.rssFeed').css({'width': '400px'});
		 $('.rssFeed').css('width', function() {
			return $(window).width() / 3.5;
			
		});

		//alert($(window).width());
}

function p_GetFeedDomain(link) {
	if (link.match(/framablog\.org/i)) return '<span class="domain">Framablog </span>';
	if (link.match(/forum.framasoft\.org/i)) return '<span class="domain">Framagora </span>';
	if (link.match(/blip\.tv/i)) return '<span class="domain">Framatube </span>';
	if (link.match(/agendadulibre\.org/i)) return '<span class="domain">Agenda </span>';
	if (link.match(/(identi\.ca|twitter)/i)) return '<span class="domain">Identi.ca </span>';
	if (link.match(/(www\.|http:\/\/)framasoft\.(org|net)/i)) return '<span class="domain">Framasoft </span>';
	return "";
}

function p_isValidEmail(emailAddress) {
var pattern = new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i);
  //return pattern.test(emailAddress);
  if (emailAddress=="") return alert("Saisissez une adresse email.")
  if (pattern.test(emailAddress)==true) {
  	//alert('On abonne '+emailAddress)
	return true;
  } else {
  	alert('Adresse email invalide.')
	return false;
  }
  return false;
}

function p_donationsTimer(t) {
	if (t) $('#donation').fadeOut(600).fadeIn(600);
	t = 30000 + Math.floor(Math.random()*30000); // random entre 30 et 60s
	setTimeout('p_donationsTimer(1)',t);
}
